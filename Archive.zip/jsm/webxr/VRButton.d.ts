import {
	WebGLRenderer
} from '../../../src/Three';

export namespace VRButton {
	export function createButton( renderer: WebGLRenderer ): HTMLElement;
}
